###############################################################################
####             Script bricole R 2020.3 sur gganimate                     ####
####                  s�ance du 21 juillet 2020                            ####
###############################################################################

##chargement des paquetages
### lancement des paquetages necessaires:
library(tidyverse)
library(FactoMineR)
library(factoextra)
library(openxlsx)
library(officer)
library(RColorBrewer)
library(ggsci)
library(gganimate)
library(ggfittext)
library(ggimage)
theme_set(theme_bw())  # pre-set the bw theme.

### d�finition du r�pertoire de travail
setwd("c:/bricoleR/2020.3") ### changez cela dans votre environnement

### traitement des donn�es: on importe tout le fichier AR 5 recod� ----
# on va travailler sur le PIB, le CO2 et la population.
data.co2 <- filter(datar5, VARIABLE == c("Emissions|CO2", "GDP|MER", "Population", "Final Energy"))
View(data.co2) #Il a bien filtr� mais on obtient un avertissement obscur ...
summary(data.co2) # on a h�las beaucoup de NAs : on aura pas des s�ries continues mais tant pis !
# cependant ce n'est pas utilisable comme cela. 
# rarrangeons les s�ries en les empilant les ann�es, pour cela on va utiliser
# la commandes pivot.longer: https://tidyr.tidyverse.org/reference/pivot_longer.html
data.co2.long <- pivot_longer(data.co2, 
                              cols = starts_with("2"),
                              names_to = "year",
                              values_to = "value",
                              values_drop_na = TRUE) # on d�barasse les NAs
View(data.co2.long) # les s�ries sont maintenant empil�es dans la variable year et value.
# maintenant nous pouvons demander des r�sum�s qui ont du sens:
data.co2.long$year <- as.factor(data.co2.long$year)
View(data.co2.long) # c'est converti en facteur
attach(data.co2.long)

## on peut aussi extraire les donn�es relatives au monde
data.co2.long <- filter(data.co2.long, REGION == "World")

# r�sum� par observations par ann�e selon ls mod�les
by(data.co2.long$year, MODEL, summary)
by(data.co2.long$year, REGION, summary) # probl�me j'aurais d� renommer le fichier filtr� sur monde autrement



## on pourrait utiliser des fonctions de dplyr tidyr pour faire des totaux plus int�ressants
## ==> on laisse cela pour la prochaine s�ance 2020.4 o� on fera du tidyverse
## ceci clot la phase de pr�paration des donn�es.


### premiers graphiques classiques non anim�s ----
# on travaille � partir du fichier long cr�� par pivot_longer():
View(data.co2.long) # �a marche !

# prenons ggplot classique dans le plan des trajectoires, ann�es -- indicateur
ggplot(data = data.co2.long, aes(x = year, y = value, group = MODEL, color = value)) +
  facet_wrap(~ VARIABLE, scales = "free_y") + # attention ! ordonn�es diff�rentes dans chaque panneau !
  scale_colour_gradient(low = "orange", high = "purple4") + # avec quatre indicateurs c'est peu parlant
  theme(axis.text.x = element_text(size = 9, angle = 45),
        axis.text.y = element_text(size = 9),
        plot.title = element_text(hjust = 0.5),
        plot.subtitle = element_text(hjust = 0.5)) +
  geom_point() +
  geom_line() +
  labs(x = "year", y = "valeurs",
       title = "Trajectoires des �missions, du PIB, de l'�nergie finale et de la population", 
       subtitle = "des scenarii SRES de l'AR 5 selon le mod�le", 
       caption = "Source : IPCC",
       colour = "Indicateur") 
### on peut aussi changer la variable de groupe:
ggplot(data = data.co2.long, aes(x = year, y = value, group = SCENARIO, color = MODEL)) +
  facet_wrap(~ VARIABLE, scales = "free_y") + # attention ! ordonn�es diff�rentes dans chaque panneau !
  theme(axis.text.x = element_text(size = 9, angle = 45),
        axis.text.y = element_text(size = 9),
        plot.title = element_text(hjust = 0.5),
        plot.subtitle = element_text(hjust = 0.5)) +
  geom_point() +
  geom_line() +
  labs(x = "year", y = "valeurs",
       title = "Trajectoires des �missions, du PIB, de l'�nergie finale et de la population", 
       subtitle = "des scenarii SRES de l'AR 5 selon le mod�le", 
       caption = "Source : IPCC",
       colour = "Indicateur")
# on pourra aussi faire des facettes selon le mod�le:
ggplot(data = data.co2.long, aes(x = year, y = value, group = SCENARIO, color = MODEL)) +
  facet_wrap(~ MODEL, scales = "free_y") + 
  theme(axis.text.x = element_text(size = 9, angle = 45),
        axis.text.y = element_text(size = 9),
        plot.title = element_text(hjust = 0.5),
        plot.subtitle = element_text(hjust = 0.5)) +
  geom_point() +
  geom_line() +
  labs(x = "year", y = "valeurs",
       title = "Trajectoires des �missions, du PIB, de l'�nergie finale et de la population", 
       subtitle = "des scenarii SRES de l'AR 5 selon le mod�le", 
       caption = "Source : IPCC",
       colour = "Mod�le") # c'est difficilement lisible et on pr�f�re une seul indicateur
## on pourra aussi faire des facettes par indicateur et MODEL:
ggplot(data = data.co2.long, aes(x = year, y = value, group = SCENARIO, color = MODEL)) +
  facet_grid(MODEL ~ VARIABLE, scales = "free_y") + 
  theme(axis.text.x = element_text(size = 9, angle = 45),
        axis.text.y = element_text(size = 6),
        plot.title = element_text(hjust = 0.5),
        plot.subtitle = element_text(hjust = 0.5)) +
  geom_point() +
  geom_line() +
  labs(x = "year", y = "valeurs",
       title = "Trajectoires des �missions, du PIB, de l'�nergie finale et de la population", 
       subtitle = "des scenarii SRES de l'AR 5 selon le mod�le", 
       caption = "Source : IPCC",
       colour = "Mod�le")
### mais cela devient difficile � lire ! C'est l� que les animations trouvent toute leur utilit� !

#### graphiques anim�s avec GGANIMATE ----------
### Une premi�re animation sur les ann�es.
transition.year <- ggplot(data = data.co2.long, 
                          aes(x = year,
                              y = value,
                              group = SCENARIO,
                              color = MODEL)) +
  facet_wrap(~ VARIABLE, scale = "free_y") + # attention ! ordonn�es diff�rentes dans chaque panneau !
  theme(axis.text.x = element_text(size = 9, angle = 45),
        axis.text.y = element_text(size = 9),
        plot.title = element_text(hjust = 0.5),
        plot.subtitle = element_text(hjust = 0.5)) +
  geom_point() +
  geom_line() +
  labs(x = "year", y = "valeurs",
       title = "Trajectoires mondiales par mod�le selon l'ann�e", 
       subtitle = "des scenarii SRES de l'AR 5 ", 
       caption = "Source : IPCC",
       colour = "Mod�le") +
  transition_reveal(along = year, keep_last = F)
  animate(transition.year)
  anim_save("transition.year.gif", last_animation())

### transition sur la couverture
  transition.coverage <- ggplot(data = data.co2.long, 
                            aes(x = year,
                                y = value,
                                group = SCENARIO,
                                color = MODEL)) +
    facet_wrap(~ VARIABLE, scale = "free_y") + # attention ! ordonn�es diff�rentes dans chaque panneau !
    theme(axis.text.x = element_text(size = 9, angle = 45),
          axis.text.y = element_text(size = 9),
          plot.title = element_text(hjust = 0.5),
          plot.subtitle = element_text(hjust = 0.5)) +
    geom_point() +
    geom_line() +
    labs(x = "year", y = "valeurs",
         title = "Trajectoires mondiales par mod�le selon: {closest_state}", 
         subtitle = "des scenarii SRES de l'AR 5 ", 
         caption = "Source : IPCC",
         colour = "Mod�le") +
    transition_states(Coverage, transition_length = 2, state_length = 4, wrap = TRUE)
  animate(transition.coverage)
  anim_save("transition.coverage.gif", last_animation())
### � valider sur d'autres variables mais il semble que l'unique mod�le �conom�trique
### n'a pas de donn�es pour les �missions et l'�nergie finale ==> cela fait planter
### le cycle d'animation sur les mod�les d'o� les messages d'erreur lorsque l'on fait la # transition sur mod�le...
  ### transition sur le nombre de substances prises en compte :
  transition.substances <- ggplot(data = data.co2.long, 
                                aes(x = year,
                                    y = value,
                                    group = SCENARIO,
                                    color = MODEL)) +
    facet_wrap(~ VARIABLE, scale = "free_y") + # attention ! ordonn�es diff�rentes dans chaque panneau !
    theme(axis.text.x = element_text(size = 9, angle = 45),
          axis.text.y = element_text(size = 9),
          plot.title = element_text(hjust = 0.5),
          plot.subtitle = element_text(hjust = 0.5)) +
    geom_point() +
    geom_line() +
    labs(x = "year", y = "valeurs",
         title = "Trajectoires mondiales par mod�le selon: {closest_state}", 
         subtitle = "des scenarii SRES de l'AR 5 ", 
         caption = "Source : IPCC",
         colour = "Mod�le") +
    transition_states(Substances, transition_length = 2, state_length = 4, wrap = TRUE)
  animate(transition.substances)
  anim_save("transition.substances.gif", last_animation())
  ### les mod�les avec 10 substances n'ont que la population comme variable projet�e !
  

### liens utiles pour approfondir:
#  https://gganimate.com/articles/gganimate.html
# https://github.com/ropenscilabs/learngganimate
# https://www.datanovia.com/en/blog/gganimate-how-to-create-plots-with-beautiful-animation-in-r/
# funny :
# https://goodekat.github.io/presentations/2019-isugg-gganimate-spooky/slides.html#32

  


